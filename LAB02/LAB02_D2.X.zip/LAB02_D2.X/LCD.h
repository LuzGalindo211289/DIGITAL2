#ifndef _XTAL_FREQ
#define _XTAL_FREQ 8000000
#endif

#define RS RE0
#define EN RE1

#ifndef LCD_H
#define	LCD_H

void Lcd_Port(char a);

void Lcd_Cmd(char a);

void Lcd_Clear();

void Lcd_Set_Cursor(char row, char column);

void Lcd_Init();

void Lcd_Write_Char(char a);

void Lcd_Write_String(char *a);

void Lcd_Shift_Right();

void Lcd_Shift_Left();

float map(int valor, float minx, float maxx, float miny, float maxy);
#endif