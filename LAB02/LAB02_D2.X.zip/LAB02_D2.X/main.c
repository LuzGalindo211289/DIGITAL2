// CONFIGURACI�N DE BITS DEL MICROCONTROLADOR
#pragma config FOSC = INTRC_NOCLKOUT   // Oscilador interno, sin salida de reloj en pin CLKOUT
#pragma config WDTE = OFF             // Watchdog Timer desactivado
#pragma config PWRTE = OFF            // Power-up Timer desactivado
#pragma config MCLRE = OFF            // MCLR/RE3 se comporta como entrada digital
#pragma config CP = OFF               // Protecci�n de c�digo desactivada
#pragma config CPD = OFF              // Protecci�n de datos desactivada
#pragma config BOREN = OFF            // Reinicio ante voltaje bajo desactivado
#pragma config IESO = OFF             // Conmutaci�n entre osciladores desactivada
#pragma config FCMEN = OFF            // Monitor de fallos de reloj desactivado
#pragma config LVP = OFF              // Programaci�n en bajo voltaje desactivada
#pragma config BOR4V = BOR40V         // Reinicio ante voltaje bajo ajustado a 4.0V
#pragma config WRT = OFF              // Protecci�n de escritura de memoria flash desactivada

#include <xc.h>
#include <stdio.h>
#include <stdint.h>
#include "LCD.h"
#include "ADC.h"
#include "EUSART.h"

// Declaraci�n de funci�n de inicializaci�n
void setup(void);

// Variables globales
uint8_t *ptr_potValue;
char *ptr_vol_int, *ptr_vol_dec1, *ptr_vol_dec2;
uint8_t counter = 157, menu_flag = 0;
char received_char;

#ifndef _XTAL_FREQ
#define _XTAL_FREQ 8000000
#endif

// Rutina de interrupci�n
void __interrupt() isr(void) {
    // Manejo de interrupci�n por recepci�n de UART
    if(PIR1bits.RCIF){
        if(RCREG == 43){
            counter++;  // Incrementar el contador si se recibe el car�cter '+'
        }
        if(RCREG == 45){
            counter--;  // Decrementar el contador si se recibe el car�cter '-'
        }
        char received_char = RCREG;

        if(received_char == 13 || received_char == 10) {
            menu_flag = 1;  // Bandera de men� activada si se recibe el car�cter 'Enter'
        }        
    }
    // Manejo de interrupci�n por finalizaci�n de conversi�n ADC
    if(ADIF){
        uint8_t potValue = adc_read();  // Leer el valor del ADC
        ptr_potValue = &potValue;       // Asignar la direcci�n del valor a un puntero
        ADIF = 0;                       // Limpiar la bandera de interrupci�n del ADC
    }
}

// Funci�n principal
void main(void) {
    setup();  // Llamar a la funci�n de inicializaci�n
    while (1) {
        __delay_ms(10);  // Peque�o retardo

        // C�lculos para mostrar el valor del potenci�metro en la LCD
        int vol = map(*ptr_potValue, 0, 255, 0, 500);
        char vol_int = vol/100 + 48;
        char vol_dec1 = (vol % 100)/10 + 48;
        char vol_dec2 = vol % 10 + 48;
        
        ptr_vol_int = &vol_int;     // Asignar direcciones de los d�gitos del voltaje a punteros
        ptr_vol_dec1 = &vol_dec1;
        ptr_vol_dec2 = &vol_dec2;
        
        PORTB = vol_int;  // Mostrar el d�gito m�s significativo del voltaje en el puerto B

        // Limpieza y escritura de datos en la LCD
        Lcd_Clear();
        Lcd_Set_Cursor(1, 1);
        Lcd_Write_String("Pot:   Contador:");
        Lcd_Set_Cursor(2, 1);
        Lcd_Write_Char(vol_int);
        Lcd_Write_Char(46);
        Lcd_Write_Char(vol_dec1);
        Lcd_Write_Char(vol_dec2);
        Lcd_Set_Cursor(2, 10);
        Lcd_Write_Char(counter/100 + 48);
        Lcd_Write_Char(counter%100/10 + 48);
        Lcd_Write_Char(counter%10 + 48);
        
        // Env�o de datos por UART si se activa la bandera de men�
        if(menu_flag){
            EUSART_write_char(13);
            EUSART_write_string("Voltaje del potenciometro: \n");
            EUSART_write_char(*ptr_vol_int);
            EUSART_write_char(46);
            EUSART_write_char(*ptr_vol_dec1);
            EUSART_write_char(*ptr_vol_dec2);
            EUSART_write_char(86);
            menu_flag = 0;
        }
        
        // Recepci�n de datos por UART
        if (RCIF) {
            received_char = EUSART_read_char();
            EUSART_write_char(received_char);
        }
        ADCON0bits.GO = 1;  // Iniciar nueva conversi�n ADC
    }
    return;
}

// Funci�n de inicializaci�n
void setup(void) {
    // Configuraci�n de puertos
    ANSEL = 0;
    ANSELH = 0;

    TRISA = 0;
    PORTA = 0;

    TRISB = 0;
    PORTB = 0;

    TRISC = 0b10000000;
    PORTC = 0;

    TRISD = 0;
    PORTD = 0;

    TRISE = 0;
    PORTE = 0;
    
    OSCCONbits.IRCF = 111;
    OSCCONbits.SCS = 1;

    // Inicializaci�n de m�dulos
    Lcd_Init();
    adc_init(0);
        
    EUSART_RX_config(9600);
    EUSART_TX_config(9600);
    
    EUSART_write_string("Presione ENTER para leer voltaje ");
}
