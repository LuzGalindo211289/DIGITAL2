#include <xc.h>
#include "LCD.h"

void Lcd_Port(char a){
    PORTD = a;                // Asignar el valor 'a' a los pines del puerto D
}

void Lcd_Cmd(char a){
	RS = 0;                   // Establecer el pin RS en 0 para indicar que se enviar� una instrucci�n
	Lcd_Port(a);               // Enviar el dato 'a' al puerto D (puerto de datos)
	EN = 1;                   // Activar el pin EN (Enable) para ejecutar la instrucci�n
    __delay_ms(4);            // Peque�o retardo para asegurar que la instrucci�n se ejecute correctamente
    EN = 0;                   // Desactivar el pin EN para finalizar la instrucci�n
}

void Lcd_Clear(){
	Lcd_Cmd(0x10);            // Enviar comando para borrar la pantalla LCD
}

void Lcd_Set_Cursor(char row, char column){
	char temp;                 // Variable temporal para determinar la posici�n del cursor
	if(row == 1){
	  temp = 0x80 + column - 1; // Calcular la posici�n de la primera fila
		Lcd_Cmd(temp);
	}
	else if(row == 2){
		temp = 0xC0 + column - 1; // Calcular la posici�n de la segunda fila
		Lcd_Cmd(temp);
	}
}

void Lcd_Init(){
    Lcd_Port(0x00);             // Inicializar el puerto de datos en 0
    __delay_ms(20);             // Esperar 20 ms para estabilizar la pantalla
    Lcd_Cmd(0x38);              // Configurar la pantalla en modo de 8 bits
    __delay_ms(5);              // Peque�o retardo para asegurar que la configuraci�n se complete
    Lcd_Cmd(0x38);              // Enviar nuevamente el comando para asegurar la configuraci�n
    __delay_ms(11);             // Peque�o retardo para asegurar que la configuraci�n se complete
    Lcd_Cmd(0x38);              // Enviar nuevamente el comando para asegurar la configuraci�n
    
    Lcd_Cmd(0x0C);              // Apagar el visualizador (no mostrar el cursor)
    __delay_ms(5);              // Peque�o retardo para asegurar que la configuraci�n se complete
    Lcd_Cmd(0x01);              // Borrar la pantalla
    Lcd_Cmd(0x06);              // Modo de entrada derecha con desplazamiento activado
}

void Lcd_Write_Char(char a){
   RS = 1;                      // Establecer el pin RS en 1 para indicar que se enviar� un dato
   Lcd_Port(a);                 // Enviar el dato 'a' al puerto D (puerto de datos)
   EN = 1;                      // Activar el pin EN (Enable) para enviar el dato
   __delay_us(40);              // Peque�o retardo para asegurar que la transmisi�n se complete correctamente
   EN = 0;                      // Desactivar el pin EN para finalizar la transmisi�n
}

void Lcd_Write_String(char *a){
	int i;
	for(i=0;a[i]!='\0';i++)
	   Lcd_Write_Char(a[i]);    // Enviar cada car�cter de la cadena al visualizador
}

void Lcd_Shift_Right(){
	Lcd_Cmd(0x1C);              // Desplazar el visualizador a la derecha
}

void Lcd_Shift_Left(){
	Lcd_Cmd(0x18);              // Desplazar el visualizador a la izquierda
}

float map(int valor, float minx, float maxx, float miny, float maxy){
    return (valor - minx) * (maxy - miny) / (maxx - minx) + miny; // Realizar el mapeo lineal de un valor a otro rango
}
