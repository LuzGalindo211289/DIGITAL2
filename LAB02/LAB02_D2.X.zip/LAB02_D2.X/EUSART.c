#define FREQ 8000000

#include <xc.h>
#include <stdint.h>
#include <stdio.h>
#include "EUSART.h"
#include <string.h>

void EUSART_Init(uint16_t baudrate){

    uint8_t baudL, baudH;
    uint16_t temp;
    
    temp = (FREQ/baudrate)/4 - 1;   // Calcular valor para el baud rate
    
    baudL = temp & 0x00FF;
    baudH = temp >> 8;
           
    // Configuraci�n de EUSART para la comunicaci�n serial
    TXSTAbits.SYNC = 0;             // Modo asincr�nico
    TXSTAbits.BRGH = 1;             // High-speed baud rate

    BAUDCTLbits.BRG16 = 1;          // Baud Rate de 16 bits
    SPBRG = baudL;                 
    SPBRGH = baudH;
    
    RCSTAbits.SPEN = 1;             // Habilitar el puerto serial
    RCSTAbits.RX9 = 0;              // Configuraci�n para 8 bits de datos
    
    // Configuraci�n de interrupciones para EUSART
    PIR1bits.RCIF = 0;              // Bandera de recepci�n (RX)
    PIE1bits.RCIE = 1;              // Habilitar la interrupci�n EUSART RX
    
    INTCONbits.PEIE = 1;            // Habilitar interrupciones perif�ricas
    INTCONbits.GIE = 1;             // Habilitar interrupciones globales
    
}

void EUSART_RX_config(uint16_t baudrate){
    EUSART_Init(baudrate);
    RCSTAbits.CREN = 1;             // Habilitar para recibir datos continuamente
    
}

void EUSART_TX_config(uint16_t baudrate){
    EUSART_Init(baudrate);
    TXSTAbits.TXEN = 1;             // Habilitar para enviar datos    
}

void EUSART_write_char(char c){
    __delay_ms(15);                 // Peque�o retardo para asegurar la transmisi�n completa del dato
    TXREG = c;                      // Escribir un caracter en el registro de transmisi�n
}

char EUSART_read_char(){
    return RCREG;                   // Regresar el valor le�do del registro de recepci�n
}

void EUSART_write_string(char c[]){
    
    int j = strlen(c);              // Obtener la longitud de la cadena
    
    for(int i = 0; i < j; ++i){     // Enviar cada car�cter de la cadena
        TXREG = c[i];
        __delay_ms(15);             // Peque�o retardo entre cada car�cter para asegurar la transmisi�n
    }
    
}
