#include <xc.h>
#include <stdint.h>
#include <stdio.h>         // for sprintf
#include "adclib.h"
/*
 * Inicializa el m�dulo del convertidor anal�gico a digital (ADC) con los par�metros dados.
 * Par�metros:
 * - channel: Canal de entrada del ADC que se desea utilizar.
 * - justf: Configura si la justificaci�n de los datos del ADC ser� a la izquierda (1) o a la derecha (0).
 * - vcf0: Configura el bit VCFG0 del registro ADCON1 para ajustar la referencia de voltaje.
 * - vcf1: Configura el bit VCFG1 del registro ADCON1 para ajustar la referencia de voltaje.
 * - adcs: Configura los bits ADCS del registro ADCON0 para determinar la velocidad de conversi�n.
 */
void adc_init(int channel, int justf, int vcf0, int vcf1, char adcs) {
    ADCON1bits.ADFM = justf; // Justificado a la izquierda
    ADCON1bits.VCFG0 = vcf0;
    ADCON1bits.VCFG1 = vcf1;
    ADCON0bits.ADON = 1; // Habilitar el m�dulo ADC
    __delay_us(50); // Esperar 50 microsegundos para estabilizar el m�dulo ADC
    ADCON0bits.ADCS = adcs; // Configurar la velocidad de conversi�n del ADC
    ADCON0bits.CHS = channel; // Configuraci�n del canal de entrada del ADC
}

/*
 * Realiza una lectura del valor digital convertido por el ADC.
 * Retorna:
 * - El valor digital convertido por el ADC almacenado en el registro ADRESH.
 */
int adc_read() {
    if (ADCON0bits.GO == 0)
        ADCON0bits.GO = 1; // Inicia una nueva conversi�n
    return ADRESH; // Retorna el valor digital convertido por el ADC
}

/*
 * Cambia el canal de entrada del ADC.
 * Par�metros:
 * - channel: Canal de entrada del ADC que se desea configurar.
 */
void adc_cchange(int channel) {
    ADCON0bits.CHS = channel; // Configura el canal de entrada del ADC
}

/*
 * Obtiene el canal de entrada actualmente configurado en el ADC.
 * Retorna:
 * - El n�mero del canal de entrada del ADC que est� actualmente configurado.
 */
int adc_get_channel() {
    return ADCON0bits.CHS; // Retorna el n�mero del canal de entrada configurado en el ADC
}
