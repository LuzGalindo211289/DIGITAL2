#ifndef     DISPLAYLIB_H
#define	DISPLAYLIB_H
#include <xc.h>
#include <stdint.h>
#include <stdio.h>         // for sprintf
#define _XTAL_FREQ 8000000
char portval;
char  valdisplay(char val); //valores del display

#endif	