#include <xc.h>
#include <stdint.h>
#include <stdio.h>         // for sprintf
#include "setup_lb.h"

/*
 * Configura los pines anal�gicos/digitales.
 * Par�metros:
 * - ans: Valor para el registro ANSEL que configura los pines AN0-AN7 como anal�gicos o digitales.
 * - ansh: Valor para el registro ANSELH que configura los pines AN8-AN12 como anal�gicos o digitales.
 */
void config_pines(char ans, int ansh) {
    ANSEL = ans;
    ANSELH = ansh;
}

/*
 * Configura los TRIS (direcciones) de los pines del microcontrolador.
 * Par�metros:
 * - tris_a: Valor para TRISA que configura las direcciones de los pines RA0-RA7.
 * - tris_b: Valor para TRISB que configura las direcciones de los pines RB0-RB7.
 * - tris_c: Valor para TRISC que configura las direcciones de los pines RC0-RC7.
 * - tris_d: Valor para TRISD que configura las direcciones de los pines RD0-RD7.
 * - tris_e: Valor para TRISE que configura las direcciones de los pines RE0-RE2.
 */
void config_tris(char tris_a, char tris_b, char tris_c, char tris_d, char tris_e) {
    TRISA = tris_a;
    TRISB = tris_b;
    TRISC = tris_c;
    TRISD = tris_d;
    TRISE = tris_e;
}

/*
 * Configura los valores de los puertos del microcontrolador.
 * Par�metros:
 * - port_a: Valor para el puerto A (PORTA).
 * - port_c: Valor para el puerto C (PORTC).
 * - port_d: Valor para el puerto D (PORTD).
 * - port_e: Valor para el puerto E (PORTE).
 */
void config_ports(char port_a, char port_c, char port_d, char port_e) {
    PORTA = port_a;
    PORTC = port_c;
    PORTD = port_d;
    PORTE = port_e;
}

/*
 * Configura las resistencias de pull-up internas en los pines RB0-RB7.
 * Par�metros:
 * - pulles: Valor para el bit nRBPU del registro OPTION_REG para habilitar (0) o deshabilitar (1) las resistencias pull-up en los pines RB0-RB7.
 * - pinpull: Valor para el registro WPUB que habilita o deshabilita las resistencias pull-up individualmente en los pines RB0-RB7.
 */
void config_pullup(int pulles, char pinpull) {
    OPTION_REGbits.nRBPU = pulles;
    WPUB = pinpull;
}

/*
 * Configura el oscilador interno del microcontrolador.
 * Par�metros:
 * - valosc: Valor para el registro OSCCONbits.IRCF que configura la frecuencia del oscilador interno.
 *           (Ejemplo: 0b0111 para configurar el oscilador a 8MHz).
 */
void config_osc(char valosc) {
    OSCCONbits.IRCF = valosc; //8MHz
    OSCCONbits.SCS = 1; // Oscilador interno habilitado (configurado como fuente de reloj principal)
}

/*
 * Configura las interrupciones del microcontrolador.
 * Par�metros:
 * - adcif: Valor para el bit ADIF del registro PIR1 para habilitar (1) o deshabilitar (0) la interrupci�n del ADC.
 * - adcie: Valor para el bit ADIE del registro PIE1 para habilitar (1) o deshabilitar (0) la interrupci�n del ADC.
 * - rbie: Valor para el bit RBIE del registro INTCON para habilitar (1) o deshabilitar (0) la interrupci�n de los botones RB0-RB7.
 * - rbif: Valor para el bit RBIF del registro INTCON para indicar (1) o no (0) que ocurri� una interrupci�n en los botones RB0-RB7.
 * - pie: Valor para el bit PEIE del registro INTCON para habilitar (1) o deshabilitar (0) las interrupciones perif�ricas.
 * - gie: Valor para el bit GIE del registro INTCON para habilitar (1) o deshabilitar (0) las interrupciones globales.
 */
void config_interrupt(int adcif, int adcie, int rbie, int rbif, int pie, int gie) {
    // Configuraci�n para la interrupci�n del ADC
    PIR1bits.ADIF = adcif;
    PIE1bits.ADIE = adcie;
    // Configuraci�n para la interrupci�n de los botones
    INTCONbits.RBIE = rbie;
    INTCONbits.RBIF = rbif;
    // Configuraci�n para las interrupciones perif�ricas y globales
    INTCONbits.PEIE = pie;
    INTCONbits.GIE = gie;
}
