#ifndef ADC_H
#define	ADC_H

#include <xc.h> 
#include <stdint.h>
#include <proc/pic16f887.h>

void OSCILATOR(uint8_t f);            

void IOC_INT(uint8_t a);

void ADC_INIT(uint8_t c);              
unsigned char ADC_READ(void);                     

#endif