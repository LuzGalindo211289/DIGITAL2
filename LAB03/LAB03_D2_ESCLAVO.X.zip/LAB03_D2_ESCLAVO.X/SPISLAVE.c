#include <stdint.h>
#include <xc.h>
#include "SPISLAVE.h"

void spiInit(Spi_Type sType, Spi_Data_Sample sDataSample, Spi_Clock_Idle sClockIdle, Spi_Transmit_Edge sTransmitEdge)
{
    TRISC5 = 0; // Configurar el pin RC5 como salida (SDO)
    
    if(sType & 0b00000100) // Si el modo es esclavo (Slave Mode)
    {
        SSPSTAT = sTransmitEdge; // Configurar la transmisi�n de datos (modo esclavo)
        TRISC3 = 1; // Configurar el pin RC3 como entrada (SDI) en modo esclavo
    }
    else // Si el modo es maestro (Master Mode)
    {
        SSPSTAT = sDataSample | sTransmitEdge; // Configurar la transmisi�n de datos (modo maestro)
        TRISC3 = 0; // Configurar el pin RC3 como salida (SDI) en modo maestro
    }
    
    SSPCON = sType | sClockIdle; // Configurar el SSPCON con la configuraci�n seleccionada
}

static void spiReceiveWait()
{
    while ( !SSPSTATbits.BF ); // Esperar hasta que se complete la recepci�n de datos
}

void spiWrite(char dat)  // Escribir datos en el bus SPI
{
    SSPBUF = dat; // Colocar el dato en el registro de buffer para ser transmitido
    
}

char spiRead(void) // Leer los datos recibidos
{
    spiReceiveWait(); // Esperar hasta que se reciban todos los bits
    return(SSPBUF); // Leer los datos recibidos desde el registro de buffer
}
