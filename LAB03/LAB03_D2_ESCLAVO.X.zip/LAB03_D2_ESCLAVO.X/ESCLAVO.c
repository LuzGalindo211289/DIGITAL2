// Configuraci�n de los bits de configuraci�n del microcontrolador
#pragma config FOSC    = INTRC_NOCLKOUT
#pragma config WDTE    = OFF
#pragma config PWRTE   = OFF
#pragma config MCLRE   = OFF
#pragma config CP      = OFF
#pragma config CPD     = OFF
#pragma config BOREN   = OFF
#pragma config IESO    = OFF
#pragma config FCMEN   = OFF
#pragma config LVP     = OFF

#pragma config BOR4V   = BOR40V
#pragma config WRT     = OFF

// Inclusi�n de librer�as y definici�n de constantes
#include <stdint.h>
#include <xc.h>
#include "SPISLAVE.h"
#include "ADC.h"
#define CONT 0xAA
#define _XTAL_FREQ  8000000

// Variables globales
uint8_t POT1, check, cont;

// Prototipo de funci�n
void setup(void);

// Rutina de interrupci�n
void __interrupt() isr(void) {
    // Interrupci�n por cambio en el puerto B
    if (INTCONbits.RBIF == 1) {
        __delay_ms(20); // Tiempo de rebote (ajusta el valor seg�n tus necesidades)
        if (RB0 == 0) {
            cont++; // Incrementar contador si RB0 est� en 0 (se puls� el bot�n)
        } else if (RB1 == 0) {
            cont--; // Decrementar contador si RB1 est� en 0 (se puls� el bot�n)
        }
        INTCONbits.RBIF = 0; // Limpiar la bandera de interrupci�n por cambio en el puerto B
    }
    // Interrupci�n de comunicaci�n SPI
    else if (PIR1bits.SSPIF == 1) {
        check = spiRead(); // Leer el dato enviado por el maestro
        if (check == CONT) {
            spiWrite(POT1); // Enviar el valor del potenci�metro al maestro
        } else {
            spiWrite(cont); // Enviar el valor del contador al maestro
        }
        PIR1bits.SSPIF = 0; // Limpiar la bandera de interrupci�n de comunicaci�n SPI
    }
}

// Funci�n principal
void main(void) {
    setup(); // Configurar el hardware
    while (1) {
        POT1 = ADC_READ(); // Leer el valor del potenci�metro
    }
    return;
}

// Funci�n de configuraci�n del hardware
void setup(void) {
    OSCILATOR(1); // Configurar el oscilador interno para funcionar a 8MHz
    
    ANSEL = 0b00100000; // Configurar AN5 como entrada anal�gica
    ANSELH = 0x00; // Configurar todas las entradas anal�gicas como entradas digitales
    
    TRISB = 0b00000011; // Configurar RB0 y RB1 como entradas (botones)
    PORTB = 0; // Limpiar el puerto B
    
    IOC_INT(0b00000011); // Habilitar interrupci�n por cambio en RB0 y RB1
    
    ADC_INIT(5); // Inicializar el m�dulo ADC para leer el potenci�metro conectado al canal 5
    
    INTCONbits.GIE = 1; // Habilitar las interrupciones globales
    INTCONbits.PEIE = 1; // Habilitar las interrupciones de perif�ricos
    PIR1bits.SSPIF = 0; // Limpiar la bandera de interrupci�n de comunicaci�n SPI
    PIE1bits.SSPIE = 1; // Habilitar las interrupciones de comunicaci�n SPI
    INTCONbits.RBIE = 1; // Habilitar la interrupci�n por cambio en el puerto B
    INTCONbits.RBIF = 0; // Limpiar la bandera de interrupci�n por cambio en el puerto B
    
    TRISAbits.TRISA5 = 1; // Configurar RA5 como entrada (Slave Select)
    
    spiInit(SPI_SLAVE_SS_EN, SPI_DATA_SAMPLE_MIDDLE, SPI_CLOCK_IDLE_LOW, SPI_IDLE_2_ACTIVE); // Inicializar el m�dulo SPI en modo esclavo
}
