#ifndef SPISLAVE_H
#define	SPISLAVE_H

#include <xc.h> 
#include <stdint.h>
#include <proc/pic16f887.h>

// Tipos enumerados para configuraci�n del modo SPI
typedef enum 
{
    SPI_MASTER_OSC_DIV4  = 0b00100000,  // Configuraci�n del maestro, oscilador interno / 4
    SPI_MASTER_OSC_DIV16 = 0b00100001,  // Configuraci�n del maestro, oscilador interno / 16
    SPI_MASTER_OSC_DIV64 = 0b00100010,  // Configuraci�n del maestro, oscilador interno / 64
    SPI_MASTER_TMR2      = 0b00100011,  // Configuraci�n del maestro, temporizador 2
    SPI_SLAVE_SS_EN      = 0b00100100,  // Modo esclavo con Slave Select habilitado
    SPI_SLAVE_SS_DIS     = 0b00100101   // Modo esclavo con Slave Select deshabilitado
}Spi_Type;

typedef enum
{
    SPI_DATA_SAMPLE_MIDDLE   = 0b00000000,  // Muestreo de datos en el medio del ciclo del reloj
    SPI_DATA_SAMPLE_END      = 0b10000000   // Muestreo de datos al final del ciclo del reloj
}Spi_Data_Sample;

typedef enum
{
    SPI_CLOCK_IDLE_HIGH  = 0b00010000,  // Reloj en estado alto en reposo (Idle)
    SPI_CLOCK_IDLE_LOW   = 0b00000000   // Reloj en estado bajo en reposo (Idle)
}Spi_Clock_Idle;

typedef enum
{
    SPI_IDLE_2_ACTIVE    = 0b00000000,  // Transmisi�n ocurre de Idle a Active (activo)
    SPI_ACTIVE_2_IDLE    = 0b01000000   // Transmisi�n ocurre de Active a Idle (inactivo)
}Spi_Transmit_Edge;


void spiInit(Spi_Type, Spi_Data_Sample, Spi_Clock_Idle, Spi_Transmit_Edge);
void spiWrite(char);  // Funci�n para enviar un byte a trav�s del bus SPI
//unsigned spiDataReady(void);  // Funci�n para verificar si hay datos listos para ser le�dos
char spiRead(void);  // Funci�n para leer un byte recibido a trav�s del bus SPI

#endif
