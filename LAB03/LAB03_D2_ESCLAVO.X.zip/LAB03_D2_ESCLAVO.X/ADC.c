#include <stdint.h>
#include <xc.h>
#include "ADC.h"
#define _XTAL_FREQ  8000000

void IOC_INT(uint8_t a){        // Configuraci�n de PULL UPS de los botones
    // Configuraci�n PULL UP
    OPTION_REGbits.nRBPU = 0;
    WPUBbits.WPUB = a;     // Habilitar PULL UP en los pines especificados por 'a'
    IOCBbits.IOCB = a;     // Habilitar interrupciones en cambio de estado en los pines especificados por 'a'
}

void OSCILATOR(uint8_t f){         // Configurar la frecuencia del oscilador
    OSCCONbits.SCS = 1;     // Seleccionar el oscilador interno como fuente del sistema

    switch(f){
        case(1):
            OSCCONbits.IRCF2 =1;        // Frecuencia del oscilador interno de 8 MHz    
            OSCCONbits.IRCF1 =1;
            OSCCONbits.IRCF0 =1;
            break;
            
        // Resto de casos para configurar otras frecuencias del oscilador interno...
    }
}

void ADC_INIT(uint8_t c){               // Configurar el m�dulo ADC para leer un canal espec�fico
    switch(c){
        // Configuraci�n para diferentes canales...
        case 0:
            ADCON0bits.CHS3 = 0;    //canal 0
            ADCON0bits.CHS2 = 0;
            ADCON0bits.CHS1 = 0;
            ADCON0bits.CHS0 = 0;
            break;
            
        case 1:
            ADCON0bits.CHS3 = 0;    //canal 1
            ADCON0bits.CHS2 = 0;
            ADCON0bits.CHS1 = 0;
            ADCON0bits.CHS0 = 1;
            break;
            
        case 2:
            ADCON0bits.CHS3 = 0;    //canal 2
            ADCON0bits.CHS2 = 0;
            ADCON0bits.CHS1 = 1;
            ADCON0bits.CHS0 = 0;
            break;
            
        case 3:
            ADCON0bits.CHS3 = 0;    //canal 3
            ADCON0bits.CHS2 = 0;
            ADCON0bits.CHS1 = 1;
            ADCON0bits.CHS0 = 1;
            break;
            
        case 4:
            ADCON0bits.CHS3 = 0;    //canal 4
            ADCON0bits.CHS2 = 1;
            ADCON0bits.CHS1 = 0;
            ADCON0bits.CHS0 = 0;
            break;
            
        case 5:
            ADCON0bits.CHS3 = 0;    //canal 5
            ADCON0bits.CHS2 = 1;
            ADCON0bits.CHS1 = 0;
            ADCON0bits.CHS0 = 1;
            break;
            
        case 6:
            ADCON0bits.CHS3 = 0;    //canal 6
            ADCON0bits.CHS2 = 1;
            ADCON0bits.CHS1 = 1;
            ADCON0bits.CHS0 = 0;
            break;
            
        case 7:
            ADCON0bits.CHS3 = 0;    //canal 7
            ADCON0bits.CHS2 = 1;
            ADCON0bits.CHS1 = 1;
            ADCON0bits.CHS0 = 1;
            break;
            
        case 8:
            ADCON0bits.CHS3 = 1;    //canal 8
            ADCON0bits.CHS2 = 0;
            ADCON0bits.CHS1 = 0;
            ADCON0bits.CHS0 = 0;
            break;
            
        case 9:
            ADCON0bits.CHS3 = 1;    //canal 9
            ADCON0bits.CHS2 = 0;
            ADCON0bits.CHS1 = 0;
            ADCON0bits.CHS0 = 1;
            break;
            
        case 10:
            ADCON0bits.CHS3 = 1;    //canal 10
            ADCON0bits.CHS2 = 0;
            ADCON0bits.CHS1 = 1;
            ADCON0bits.CHS0 = 0;
            break;
            
        case 11:
            ADCON0bits.CHS3 = 1;    //canal 11
            ADCON0bits.CHS2 = 0;
            ADCON0bits.CHS1 = 1;
            ADCON0bits.CHS0 = 1;
            break;
            
        case 12:
            ADCON0bits.CHS3 = 1;    //canal 12
            ADCON0bits.CHS2 = 1;
            ADCON0bits.CHS1 = 0;
            ADCON0bits.CHS0 = 0;
            break;
            
        case 13:
            ADCON0bits.CHS3 = 1;    //canal 13
            ADCON0bits.CHS2 = 1;
            ADCON0bits.CHS1 = 0;
            ADCON0bits.CHS0 = 1;
            break;
            
        default:
            ADCON0bits.CHS3 = 0;    //canal 0
            ADCON0bits.CHS2 = 0;
            ADCON0bits.CHS1 = 0;
            ADCON0bits.CHS0 = 0;
            break;
    }
    
    ADCON1bits.VCFG0 = 0;   // VDD como referencia positiva para el ADC
    ADCON1bits.VCFG1 = 0;   // VSS como referencia negativa para el ADC
    
    ADCON0bits.ADCS0 = 0;   // Frecuencia de conversi�n del ADC: fosc/32
    ADCON0bits.ADCS1 = 1;

    ADCON1bits.ADFM = 0;    // Justificaci�n a la izquierda (resultados en ADRESH y ADRESL)
    
    ADCON0bits.ADON = 1;    // Habilitar el m�dulo ADC 
    __delay_us(50);
    ADCON0bits.GO_nDONE = 1; // Iniciar una conversi�n ADC
}

unsigned char ADC_READ(void){                     // Leer el valor del potenci�metro mediante el ADC
    ADCON0bits.GO_nDONE = 1; // Iniciar una nueva conversi�n
    __delay_ms(50); // Esperar el tiempo de conversi�n (ajustar el valor seg�n la frecuencia del oscilador y el canal seleccionado)
    while(ADCON0bits.GO_nDONE == 1); // Esperar hasta que la conversi�n est� lista
    return ADRESH; // Obtener el resultado de la conversi�n desde el registro ADRESH
}
