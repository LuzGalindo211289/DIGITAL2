#pragma config FOSC = INTRC_NOCLKOUT
#pragma config WDTE = OFF
#pragma config PWRTE = OFF
#pragma config MCLRE = OFF
#pragma config CP = OFF
#pragma config CPD = OFF
#pragma config BOREN = OFF
#pragma config IESO = OFF
#pragma config FCMEN = OFF
#pragma config LVP = OFF

#pragma config BOR4V = BOR40V
#pragma config WRT = OFF

#include <stdint.h>
#include <xc.h>
#include "LCD.h"
#include "SPIMASTER.h"
#define FLAG_SPI 0xFF
#define CONT 0xAA
#define _XTAL_FREQ 8000000

uint8_t unidad, decena, centena; // Variables para almacenar las unidades, decenas y centenas de los valores le�dos
uint8_t POT1, POT2, cont; // Variables para almacenar los valores le�dos de los potenci�metros y el contador
uint8_t cont_display; // Variable para el contador a mostrar en la pantalla del LCD

void setup(void);
void updateSlaveData(void);
void printLCDValues(void);

void main(void) {
    setup(); // Configuraci�n inicial

    while (1) {
        updateSlaveData(); // Actualizar datos de los esclavos
        printLCDValues(); // Mostrar los valores en el LCD
    }

    return;
}

void setup(void) {
    // Configuraci�n de pines y perif�ricos
    ANSEL = 0x00;
    ANSELH = 0x00;

    TRISCbits.TRISC2 = 0; // Pin de selecci�n para el esclavo S1
    TRISCbits.TRISC1 = 0; // Pin de selecci�n para el esclavo S2
    TRISB = 0x00;
    TRISD = 0x00;

    PORTD = 0x00;
    PORTB = 0x00;
    PORTCbits.RC2 = 1;
    PORTCbits.RC1 = 1;

    LCD_INIT(); // Inicializar LCD
    spiInit(SPI_MASTER_OSC_DIV4, SPI_DATA_SAMPLE_MIDDLE, SPI_CLOCK_IDLE_LOW, SPI_IDLE_2_ACTIVE); // Inicializar comunicaci�n SPI como maestro
}

void updateSlaveData(void) {
    // Leer datos del esclavo S1
    PORTCbits.RC2 = 0; // Seleccionar esclavo S1
    PORTCbits.RC1 = 1; // Deseleccionar esclavo S2
    __delay_ms(1);

    spiWrite(CONT); // Enviar comando para solicitar contador o potenci�metro al esclavo S1
    __delay_ms(1);
    cont = spiRead(); // Leer la respuesta del esclavo S1

    __delay_ms(1);

    // Leer datos del esclavo S2
    PORTCbits.RC2 = 1; // Deseleccionar esclavo S1
    PORTCbits.RC1 = 0; // Seleccionar esclavo S2
    __delay_ms(1);

    spiWrite(FLAG_SPI); // Enviar un valor cualquiera para iniciar la comunicaci�n con el esclavo S2
    POT2 = spiRead(); // Leer el valor del potenci�metro del esclavo S2
    __delay_ms(1);

    // Leer datos del esclavo S1 nuevamente
    PORTCbits.RC2 = 0; // Seleccionar esclavo S1
    PORTCbits.RC1 = 1; // Deseleccionar esclavo S2
    __delay_ms(1);

    spiWrite(FLAG_SPI);
    POT1 = spiRead(); // Leer el valor del potenci�metro del esclavo S1

    __delay_ms(1);

    PORTCbits.RC2 = 1; // Deseleccionar esclavo S1 (para evitar problemas con S1)
    PORTCbits.RC1 = 1; // Deseleccionar esclavo S2
}

void printLCDValues(void) {
    // Separar las unidades, decenas y centenas del valor del potenci�metro del esclavo S1
    centena = CENTENA(POT1);
    decena = DECENA(POT1);
    unidad = UNIDAD(POT1);

    centena += 48; // Convertir las cifras en caracteres ASCII
    decena += 48;
    unidad += 48;

    LCD_CLEAR(); // Limpiar la pantalla del LCD
    LCD_XY(1, 0);
    LCD_STRING("S1:  cont: S2:");
    LCD_XY(2, 0);
    LCD_CHAR(centena);
    LCD_STRING(".");
    LCD_CHAR(decena);
    LCD_CHAR(unidad);

    // Separar las unidades, decenas y centenas del valor del contador del esclavo S1
    centena = CENTENA_C(cont);
    decena = DECENA_C(cont);
    unidad = UNIDAD_C(cont);

    centena += 48; // Convertir las cifras en caracteres ASCII
    decena += 48;
    unidad += 48;

    LCD_XY(2, 6);
    LCD_CHAR(centena);
    LCD_CHAR(decena);
    LCD_CHAR(unidad);

    // Separar las unidades, decenas y centenas del valor del potenci�metro del esclavo S2
    centena = CENTENA(POT2);
    decena = DECENA(POT2);
    unidad = UNIDAD(POT2);

    centena += 48; // Convertir las cifras en caracteres ASCII
    decena += 48;
    unidad += 48;

    LCD_XY(2, 11);
    LCD_CHAR(centena);
    LCD_STRING(".");
    LCD_CHAR(decena);
    LCD_CHAR(unidad);
}
