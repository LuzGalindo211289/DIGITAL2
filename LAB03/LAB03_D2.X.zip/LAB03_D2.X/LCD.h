#ifndef LCD_H
#define	LCD_H

#include <xc.h>  
#include <stdint.h>
#include <proc/pic16f887.h>

void LCD_PORT(char a);
void LCD_COM(char a);
void LCD_CLEAR(void);
void LCD_XY(char x, char y);
void LCD_INIT(void);
void LCD_CHAR(char a);
void LCD_STRING(char *a);

uint8_t DECENA(unsigned char c);       
uint8_t UNIDAD(unsigned char c);       
uint8_t CENTENA(unsigned char c);
uint8_t DECENA_C(unsigned char c);       
uint8_t UNIDAD_C(unsigned char c);       
uint8_t CENTENA_C(unsigned char c);

#define PORT PORTB
#define RS_PIN RD6
#define E_PIN RD7

#endif	