#ifndef SPISLAVE_H
#define	SPISLAVE_H

#include <xc.h> 
#include <stdint.h>
#include <proc/pic16f887.h>

typedef enum 
{
    SPI_MASTER_OSC_DIV4  = 0b00100000,   // Configuraci�n del m�dulo SPI en modo maestro, con divisor de oscilador 4
    SPI_MASTER_OSC_DIV16 = 0b00100001,   // Configuraci�n del m�dulo SPI en modo maestro, con divisor de oscilador 16
    SPI_MASTER_OSC_DIV64 = 0b00100010,   // Configuraci�n del m�dulo SPI en modo maestro, con divisor de oscilador 64
    SPI_MASTER_TMR2      = 0b00100011,   // Configuraci�n del m�dulo SPI en modo maestro, usando el temporizador TMR2 como base de tiempo
    SPI_SLAVE_SS_EN      = 0b00100100,   // Configuraci�n del m�dulo SPI en modo esclavo con el pin SS (Slave Select) habilitado
    SPI_SLAVE_SS_DIS     = 0b00100101    // Configuraci�n del m�dulo SPI en modo esclavo con el pin SS (Slave Select) deshabilitado
} Spi_Type;

typedef enum
{
    SPI_DATA_SAMPLE_MIDDLE   = 0b00000000,   // Configuraci�n para muestreo de datos en el centro del bit de reloj (modo maestro)
    SPI_DATA_SAMPLE_END      = 0b10000000    // Configuraci�n para muestreo de datos al final del bit de reloj (modo maestro)
} Spi_Data_Sample;

typedef enum
{
    SPI_CLOCK_IDLE_HIGH  = 0b00010000,   // Configuraci�n para mantener el reloj SPI en nivel alto en estado de reposo
    SPI_CLOCK_IDLE_LOW   = 0b00000000    // Configuraci�n para mantener el reloj SPI en nivel bajo en estado de reposo
} Spi_Clock_Idle;

typedef enum
{
    SPI_IDLE_2_ACTIVE    = 0b00000000,   // Configuraci�n para transici�n del estado inactivo al activo del reloj SPI
    SPI_ACTIVE_2_IDLE    = 0b01000000    // Configuraci�n para transici�n del estado activo al inactivo del reloj SPI
} Spi_Transmit_Edge;

void spiInit(Spi_Type, Spi_Data_Sample, Spi_Clock_Idle, Spi_Transmit_Edge);   // Inicializar el m�dulo SPI con las configuraciones proporcionadas
void spiWrite(char);    // Enviar un byte de datos a trav�s del bus SPI
char spiRead(void);     // Leer un byte de datos recibidos desde el bus SPI

#endif
