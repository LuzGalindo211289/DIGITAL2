#ifndef ADC1_H
#define	ADC1_H

#include <xc.h>  
#include <stdint.h>
#include <proc/pic16f887.h>

void OSCILATOR(uint8_t f);
void ADC_INIT(uint8_t c);                 
unsigned char ADC_READ(void);                 

#endif