#include <stdint.h>
#include <xc.h>
#include "SPISLAVE.h"
#include "ADC1.h"

// Variables globales
uint8_t POT2;

// Prototipos de funciones
void setup(void);

void __interrupt() isr(void){
    if(PIR1bits.SSPIF == 1){
        spiWrite(POT2);
        PIR1bits.SSPIF = 0;
    }
}

void main(void) {
    setup();
    while(1){
        POT2 = ADC_READ(); 
    }
    return;
}

void setup(void){
    // Configuraci�n de los pines para el oscilador
    OSCCON = 0b01110000; // FOSC = INTRC_NOCLKOUT
    
    // Configuraci�n de los pines para el ADC
    ANSEL =  0b00100000;
    ANSELH = 0x00;
    
    // Configuraci�n del ADC en el canal 5
    ADC_INIT(5);
    
    // Habilitar interrupciones
    INTCONbits.GIE = 1;
    INTCONbits.PEIE = 1;
    PIR1bits.SSPIF = 0;
    PIE1bits.SSPIE = 1;
    
    // Configurar el pin RA5 como entrada para el Slave Select
    TRISAbits.TRISA5 = 1;
    
    // Inicializar la comunicaci�n SPI en modo esclavo
    spiInit(SPI_SLAVE_SS_EN, SPI_DATA_SAMPLE_MIDDLE, SPI_CLOCK_IDLE_LOW, SPI_IDLE_2_ACTIVE);
}
